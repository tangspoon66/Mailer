﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;
using S22.Imap;
using System.Net.Mime;
using Limilabs.Client.IMAP;
using Limilabs.Mail.MIME;
using Limilabs.Mail;

namespace Mailer
{
    public partial class Form1 : Form
    {
        NetworkCredential login;
        SmtpClient client;
        MailMessage msg;
        static Form1 f;
        public Form1()
        {
            InitializeComponent();
            f = this;
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            //验证
            login = new NetworkCredential(txtUsername.Text, txtPassword.Text);
            //获取Smtp服务器框中的内容
            client = new SmtpClient(txtSmtp.Text);
            //端口
            client.Port = Convert.ToInt32(txtPort.Text);
            //ssl
            client.EnableSsl = chkSSL.Checked;
            client.Credentials = login;
            msg = new MailMessage { From = new MailAddress(txtUsername.Text, "匙羹", Encoding.UTF8) };
            msg.To.Add(new MailAddress(txtTo.Text));
            //开始赋值
            msg.Subject = txtSubject.Text;
            msg.Body = txtMessage.Text;
            msg.BodyEncoding = Encoding.UTF8;
            msg.IsBodyHtml = false;
            
           
            if(txtAttachment.Text!="")
            {
                Attachment data = new Attachment(txtAttachment.Text);
                msg.Attachments.Add(data);
            }
            msg.Priority = MailPriority.Normal;//Normal相对于High
            msg.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;
            client.SendCompleted += new SendCompletedEventHandler(SendCompletedCallback);
           
            string userstate = "sending...";
            client.SendAsync(msg, userstate);
            txtTo.Text = null;
            txtSubject.Text = null;
            txtMessage.Text = null;
        }

        private static void SendCompletedCallback(object sender, AsyncCompletedEventArgs e)
        {
            if (e.Cancelled)
                MessageBox.Show(string.Format("{0} send canceled.", e.UserState), "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            if (e.Error != null)
                MessageBox.Show(string.Format("{0} {1}", e.UserState, e.Error), "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show("Your message has been sucessfully sent!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            if(dlg.ShowDialog()==DialogResult.OK)
            {
                txtAttachment.Text = dlg.FileName.ToString();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnReceive_Click(object sender, EventArgs e)
        {
            StarReceiving();
        }
        private void StarReceiving()
        {
            //Net framework 4.5以上使用
            Task.Run(() =>
            {
                //接收服务器信息
                using (ImapClient client = new ImapClient(txtImap.Text, 993, txtReceiveUsername.Text, txtReceivePassword.Text, AuthMethod.Login, true))
                {
                    if (client.Supports("IDLE") == false)
                    {
                        MessageBox.Show("Server does not suport IMMAP IDLE");
                        return;
                    }
                    client.NewMessage += new EventHandler<IdleMessageEventArgs>(OnNewMessage);
                    while (true) ;
                }
            });
        }

        private void OnNewMessage(object sender, IdleMessageEventArgs e)
        {

            MessageBox.Show("收到新的邮件，请及时查看。");
            MailMessage m = e.Client.GetMessage(e.MessageUID, FetchOptions.Normal);
            f.Invoke((MethodInvoker)delegate
            {
                f.txtReceive.AppendText("来自："+m.From + "的邮件"+"\r\n");
                f.txtReceive.AppendText("主题：" + m.Subject + "\r\n");
                f.txtReceive.AppendText("正文：" + m.Body + "\r\n");
      
               
                if(txtAttachment.Text!="")
                {
                    
                    f.txtReceive.AppendText("该邮件含有附件，点击下方按钮下载\r\n");
                }
                
            });
        }

        private void Smtpqq_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            txtUsername.Text = "tangspoon@qq.com";
            txtPassword.Text = "avxjflebywuahhba";
            txtPort.Text = "587";
            txtSmtp.Text= "smtp.qq.com";
        }

        private void Smtp163_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            txtUsername.Text = "tang_qigen@163.com";
            txtPassword.Text = "tangspoon163";
            txtPort.Text = "465";
            txtSmtp.Text = "smtp.163.com";
        }

        private void Smtpgmail_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            txtUsername.Text = "tangspoon6666@gmail.com";
            txtPassword.Text = "1151122086Tqg";
            txtPort.Text = "587";
            txtSmtp.Text = "smtp.gmail.com";
            MessageBox.Show("发送gmail邮件需要打开全局VPN，否则发送失败。点击“确认”后继续。");

        }

        private void Smtpoutlook_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            txtUsername.Text = "tangspoon@outlook.com";
            txtPassword.Text = "1151122086Tqg";
            txtPort.Text = "587";
            txtSmtp.Text = "smtp.outlook.com";
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void imapqq_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            txtImap.Text = "imap.qq.com";
            txtReceiveUsername.Text = "tangspoon@qq.com";
            txtReceivePassword.Text="avxjflebywuahhba";
        }

        private void imap163_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            txtImap.Text = "imap.163.com";
            txtReceiveUsername.Text = "tang_qigen@163.com";
            txtReceivePassword.Text = "tangspoon163";
        }

        private void imapgmail_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            txtImap.Text = "imap.gmail.com";
            txtReceiveUsername.Text = "tangspoon6666@gmail.com";
            txtReceivePassword.Text = "1151122086Tqg";
        }

        private void imapoutlook_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            txtImap.Text = "imap.outlook.com";
            txtReceiveUsername.Text = "tangspoon@outlook.com";
            txtReceivePassword.Text = "1151122086Tqg";
        }
      

        }
        
    }

