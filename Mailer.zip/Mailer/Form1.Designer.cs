﻿namespace Mailer
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSend = new System.Windows.Forms.Button();
            this.Setting = new System.Windows.Forms.GroupBox();
            this.chkSSL = new System.Windows.Forms.CheckBox();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtSmtp = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtTo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSubject = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtAttachment = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtImap = new System.Windows.Forms.TextBox();
            this.txtReceivePassword = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtReceiveUsername = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnReceive = new System.Windows.Forms.Button();
            this.txtReceive = new System.Windows.Forms.TextBox();
            this.Smtpqq = new System.Windows.Forms.LinkLabel();
            this.Smtp163 = new System.Windows.Forms.LinkLabel();
            this.Smtpgmail = new System.Windows.Forms.LinkLabel();
            this.Smtpoutlook = new System.Windows.Forms.LinkLabel();
            this.imapqq = new System.Windows.Forms.LinkLabel();
            this.imap163 = new System.Windows.Forms.LinkLabel();
            this.imapgmail = new System.Windows.Forms.LinkLabel();
            this.imapoutlook = new System.Windows.Forms.LinkLabel();
            this.Setting.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(157, 482);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(148, 36);
            this.btnSend.TabIndex = 5;
            this.btnSend.Text = "发送";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // Setting
            // 
            this.Setting.Controls.Add(this.Smtpoutlook);
            this.Setting.Controls.Add(this.Smtpgmail);
            this.Setting.Controls.Add(this.Smtp163);
            this.Setting.Controls.Add(this.Smtpqq);
            this.Setting.Controls.Add(this.chkSSL);
            this.Setting.Controls.Add(this.txtUsername);
            this.Setting.Controls.Add(this.label5);
            this.Setting.Controls.Add(this.label8);
            this.Setting.Controls.Add(this.txtSmtp);
            this.Setting.Controls.Add(this.label7);
            this.Setting.Controls.Add(this.txtPort);
            this.Setting.Controls.Add(this.label6);
            this.Setting.Controls.Add(this.txtPassword);
            this.Setting.Location = new System.Drawing.Point(29, 20);
            this.Setting.Name = "Setting";
            this.Setting.Size = new System.Drawing.Size(350, 195);
            this.Setting.TabIndex = 2;
            this.Setting.TabStop = false;
            this.Setting.Text = "用户信息";
            // 
            // chkSSL
            // 
            this.chkSSL.AutoSize = true;
            this.chkSSL.Checked = true;
            this.chkSSL.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkSSL.Location = new System.Drawing.Point(255, 100);
            this.chkSSL.Name = "chkSSL";
            this.chkSSL.Size = new System.Drawing.Size(42, 16);
            this.chkSSL.TabIndex = 3;
            this.chkSSL.Text = "SSL";
            this.chkSSL.UseVisualStyleBackColor = true;
            // 
            // txtUsername
            // 
            this.txtUsername.Location = new System.Drawing.Point(128, 25);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(169, 21);
            this.txtUsername.TabIndex = 0;
            this.txtUsername.Text = "tangspoon@qq.com";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 10F);
            this.label5.Location = new System.Drawing.Point(24, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 14);
            this.label5.TabIndex = 2;
            this.label5.Text = "邮箱地址：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("宋体", 10F);
            this.label8.Location = new System.Drawing.Point(31, 136);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 14);
            this.label8.TabIndex = 2;
            this.label8.Text = "smtp服务器：";
            // 
            // txtSmtp
            // 
            this.txtSmtp.Location = new System.Drawing.Point(128, 131);
            this.txtSmtp.Name = "txtSmtp";
            this.txtSmtp.Size = new System.Drawing.Size(169, 21);
            this.txtSmtp.TabIndex = 4;
            this.txtSmtp.Text = "smtp.qq.com";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("宋体", 10F);
            this.label7.Location = new System.Drawing.Point(73, 97);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 14);
            this.label7.TabIndex = 2;
            this.label7.Text = "端口：";
            // 
            // txtPort
            // 
            this.txtPort.Location = new System.Drawing.Point(128, 95);
            this.txtPort.Name = "txtPort";
            this.txtPort.Size = new System.Drawing.Size(100, 21);
            this.txtPort.TabIndex = 2;
            this.txtPort.Text = "587";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("宋体", 10F);
            this.label6.Location = new System.Drawing.Point(24, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 14);
            this.label6.TabIndex = 2;
            this.label6.Text = "密码/授权码：";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(128, 57);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(169, 21);
            this.txtPassword.TabIndex = 1;
            this.txtPassword.Text = "avxjflebywuahhba";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 10F);
            this.label1.Location = new System.Drawing.Point(26, 243);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 14);
            this.label1.TabIndex = 2;
            this.label1.Text = "收件人：";
            // 
            // txtTo
            // 
            this.txtTo.Location = new System.Drawing.Point(86, 241);
            this.txtTo.Name = "txtTo";
            this.txtTo.Size = new System.Drawing.Size(350, 21);
            this.txtTo.TabIndex = 0;
            this.txtTo.Text = "tangspoon@qq.com";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 10F);
            this.label3.Location = new System.Drawing.Point(26, 275);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 14);
            this.label3.TabIndex = 2;
            this.label3.Text = "主题：";
            // 
            // txtSubject
            // 
            this.txtSubject.Location = new System.Drawing.Point(86, 273);
            this.txtSubject.Name = "txtSubject";
            this.txtSubject.Size = new System.Drawing.Size(350, 21);
            this.txtSubject.TabIndex = 1;
            this.txtSubject.Text = "接收邮件测试";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 10F);
            this.label4.Location = new System.Drawing.Point(26, 307);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 14);
            this.label4.TabIndex = 2;
            this.label4.Text = "正文：";
            // 
            // txtMessage
            // 
            this.txtMessage.Location = new System.Drawing.Point(86, 305);
            this.txtMessage.Multiline = true;
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtMessage.Size = new System.Drawing.Size(350, 134);
            this.txtMessage.TabIndex = 3;
            this.txtMessage.Text = "接收邮件测试";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("宋体", 10F);
            this.label9.Location = new System.Drawing.Point(26, 453);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 14);
            this.label9.TabIndex = 2;
            this.label9.Text = "附件：";
            // 
            // txtAttachment
            // 
            this.txtAttachment.Location = new System.Drawing.Point(86, 451);
            this.txtAttachment.Name = "txtAttachment";
            this.txtAttachment.Size = new System.Drawing.Size(243, 21);
            this.txtAttachment.TabIndex = 3;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(361, 448);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnBrowse.TabIndex = 4;
            this.btnBrowse.Text = "浏览...";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtTo);
            this.groupBox1.Controls.Add(this.btnBrowse);
            this.groupBox1.Controls.Add(this.Setting);
            this.groupBox1.Controls.Add(this.txtMessage);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtSubject);
            this.groupBox1.Controls.Add(this.txtAttachment);
            this.groupBox1.Controls.Add(this.btnSend);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(462, 543);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "发送箱";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.imapoutlook);
            this.groupBox2.Controls.Add(this.imapgmail);
            this.groupBox2.Controls.Add(this.imap163);
            this.groupBox2.Controls.Add(this.imapqq);
            this.groupBox2.Controls.Add(this.txtImap);
            this.groupBox2.Controls.Add(this.txtReceivePassword);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.txtReceiveUsername);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.btnReceive);
            this.groupBox2.Controls.Add(this.txtReceive);
            this.groupBox2.Location = new System.Drawing.Point(495, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(397, 543);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "收件箱";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // txtImap
            // 
            this.txtImap.Location = new System.Drawing.Point(143, 66);
            this.txtImap.Name = "txtImap";
            this.txtImap.Size = new System.Drawing.Size(152, 21);
            this.txtImap.TabIndex = 3;
            this.txtImap.Text = "imap.qq.com";
            // 
            // txtReceivePassword
            // 
            this.txtReceivePassword.Location = new System.Drawing.Point(143, 39);
            this.txtReceivePassword.Name = "txtReceivePassword";
            this.txtReceivePassword.PasswordChar = '*';
            this.txtReceivePassword.Size = new System.Drawing.Size(152, 21);
            this.txtReceivePassword.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(69, 70);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 12);
            this.label11.TabIndex = 2;
            this.label11.Text = "IMAP服务器：";
            // 
            // txtReceiveUsername
            // 
            this.txtReceiveUsername.Location = new System.Drawing.Point(143, 12);
            this.txtReceiveUsername.Name = "txtReceiveUsername";
            this.txtReceiveUsername.Size = new System.Drawing.Size(152, 21);
            this.txtReceiveUsername.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(69, 43);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 12);
            this.label10.TabIndex = 2;
            this.label10.Text = "密码：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(69, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "接收邮箱：";
            // 
            // btnReceive
            // 
            this.btnReceive.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnReceive.Location = new System.Drawing.Point(161, 118);
            this.btnReceive.Name = "btnReceive";
            this.btnReceive.Size = new System.Drawing.Size(106, 22);
            this.btnReceive.TabIndex = 1;
            this.btnReceive.Text = "登录并接收";
            this.btnReceive.UseVisualStyleBackColor = true;
            this.btnReceive.Click += new System.EventHandler(this.btnReceive_Click);
            // 
            // txtReceive
            // 
            this.txtReceive.Location = new System.Drawing.Point(38, 151);
            this.txtReceive.Multiline = true;
            this.txtReceive.Name = "txtReceive";
            this.txtReceive.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtReceive.Size = new System.Drawing.Size(320, 382);
            this.txtReceive.TabIndex = 0;
            // 
            // Smtpqq
            // 
            this.Smtpqq.AutoSize = true;
            this.Smtpqq.LinkColor = System.Drawing.SystemColors.HotTrack;
            this.Smtpqq.Location = new System.Drawing.Point(120, 167);
            this.Smtpqq.Name = "Smtpqq";
            this.Smtpqq.Size = new System.Drawing.Size(41, 12);
            this.Smtpqq.TabIndex = 5;
            this.Smtpqq.TabStop = true;
            this.Smtpqq.Tag = "";
            this.Smtpqq.Text = "qq邮箱";
            this.Smtpqq.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Smtpqq_LinkClicked);
            // 
            // Smtp163
            // 
            this.Smtp163.AutoSize = true;
            this.Smtp163.LinkColor = System.Drawing.SystemColors.HotTrack;
            this.Smtp163.Location = new System.Drawing.Point(164, 167);
            this.Smtp163.Name = "Smtp163";
            this.Smtp163.Size = new System.Drawing.Size(47, 12);
            this.Smtp163.TabIndex = 5;
            this.Smtp163.TabStop = true;
            this.Smtp163.Text = "163邮箱";
            this.Smtp163.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Smtp163_LinkClicked);
            // 
            // Smtpgmail
            // 
            this.Smtpgmail.AutoSize = true;
            this.Smtpgmail.LinkColor = System.Drawing.SystemColors.HotTrack;
            this.Smtpgmail.Location = new System.Drawing.Point(215, 167);
            this.Smtpgmail.Name = "Smtpgmail";
            this.Smtpgmail.Size = new System.Drawing.Size(35, 12);
            this.Smtpgmail.TabIndex = 6;
            this.Smtpgmail.TabStop = true;
            this.Smtpgmail.Text = "gmail";
            this.Smtpgmail.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Smtpgmail_LinkClicked);
            // 
            // Smtpoutlook
            // 
            this.Smtpoutlook.AutoSize = true;
            this.Smtpoutlook.LinkColor = System.Drawing.SystemColors.HotTrack;
            this.Smtpoutlook.Location = new System.Drawing.Point(256, 167);
            this.Smtpoutlook.Name = "Smtpoutlook";
            this.Smtpoutlook.Size = new System.Drawing.Size(47, 12);
            this.Smtpoutlook.TabIndex = 6;
            this.Smtpoutlook.TabStop = true;
            this.Smtpoutlook.Text = "outlook";
            this.Smtpoutlook.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Smtpoutlook_LinkClicked);
            // 
            // imapqq
            // 
            this.imapqq.AutoSize = true;
            this.imapqq.Location = new System.Drawing.Point(130, 94);
            this.imapqq.Name = "imapqq";
            this.imapqq.Size = new System.Drawing.Size(41, 12);
            this.imapqq.TabIndex = 4;
            this.imapqq.TabStop = true;
            this.imapqq.Text = "qq邮箱";
            this.imapqq.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.imapqq_LinkClicked);
            // 
            // imap163
            // 
            this.imap163.AutoSize = true;
            this.imap163.Location = new System.Drawing.Point(178, 93);
            this.imap163.Name = "imap163";
            this.imap163.Size = new System.Drawing.Size(47, 12);
            this.imap163.TabIndex = 5;
            this.imap163.TabStop = true;
            this.imap163.Text = "163邮箱";
            this.imap163.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.imap163_LinkClicked);
            // 
            // imapgmail
            // 
            this.imapgmail.AutoSize = true;
            this.imapgmail.Location = new System.Drawing.Point(232, 93);
            this.imapgmail.Name = "imapgmail";
            this.imapgmail.Size = new System.Drawing.Size(35, 12);
            this.imapgmail.TabIndex = 6;
            this.imapgmail.TabStop = true;
            this.imapgmail.Text = "gmail";
            this.imapgmail.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.imapgmail_LinkClicked);
            // 
            // imapoutlook
            // 
            this.imapoutlook.AutoSize = true;
            this.imapoutlook.Location = new System.Drawing.Point(273, 94);
            this.imapoutlook.Name = "imapoutlook";
            this.imapoutlook.Size = new System.Drawing.Size(47, 12);
            this.imapoutlook.TabIndex = 7;
            this.imapoutlook.TabStop = true;
            this.imapoutlook.Text = "outlook";
            this.imapoutlook.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.imapoutlook_LinkClicked);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(923, 567);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mailer";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Setting.ResumeLayout(false);
            this.Setting.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.GroupBox Setting;
        private System.Windows.Forms.CheckBox chkSSL;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtSmtp;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtPort;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSubject;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtAttachment;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnReceive;
        private System.Windows.Forms.TextBox txtReceive;
        private System.Windows.Forms.TextBox txtReceivePassword;
        private System.Windows.Forms.TextBox txtReceiveUsername;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtImap;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.LinkLabel Smtpoutlook;
        private System.Windows.Forms.LinkLabel Smtpgmail;
        private System.Windows.Forms.LinkLabel Smtp163;
        private System.Windows.Forms.LinkLabel Smtpqq;
        private System.Windows.Forms.LinkLabel imapqq;
        private System.Windows.Forms.LinkLabel imap163;
        private System.Windows.Forms.LinkLabel imapgmail;
        private System.Windows.Forms.LinkLabel imapoutlook;
    }
}

